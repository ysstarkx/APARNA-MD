<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
## Hermit Md Whatsapp Bot
Hermit-md - Simple whatsapp Multi Device bot based on @adiwajshing/baileys

***

### SETUP

1. Scan the QR.
    <br>
<a href='https://baileys-md-qr.herokuapp.com/deployment' target="_blank"><img alt='SCAN QR' src='https://img.shields.io/badge/Scan_qr-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=black&color=black'/></a>

***

2. If You don't have a account in Heroku Create a account.
    <br>
<a href='https://signup.heroku.com/' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-Create-black?style=for-the-badge&logo=heroku&logoColor=white'/></a>

***

3. Now Deploy
    <br>
<a href='https://baileys-md-qr.herokuapp.com/deploy' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-DEPLOY-black?style=for-the-badge&logo=heroku&logoColor=white'/></a>


***
* Join Group For Help
<a href="https://chat.whatsapp.com/LOMGBEO2i9vKew562o1LFk"><img alt="WhatsApp" src="https://img.shields.io/badge/-Whatsapp%20Group-black?style=for-the-badge&logo=whatsapp&logoColor=white"/></a>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
